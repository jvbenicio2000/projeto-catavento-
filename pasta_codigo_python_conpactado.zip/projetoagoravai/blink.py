from machine import Pin, ADC, PWM
import utime
import math

POT_PIN = 26	#pino potenciômetro
pin_step = Pin(22, Pin.OUT)
pin_dir = Pin(21, Pin.OUT)
pin_enable = Pin(20, Pin.OUT)

pot = ADC(POT_PIN)	#define o GPIO26 como ADC0

pin_enable.value(0)  # LOW = ativado no DRV8825
tensao= Pin(27, Pin.IN)  # Define o pino GP27 como entrada
tensao_motor = ADC(tensao)  # Usa o GP27, que é o ADC1
porta_led=Pin(19)
led_pwm = PWM(porta_led)  # Define GP15 como saída PWM
led_pwm.freq(1000)  # Define a frequência do PWM
posicao = 0	#váriavel que armazena a posição do motor
valor_bruto=0

def ler_potenciometro():	#função para ler o pot
     valor_raw = pot.read_u16()
     global valor
     valor = valor_raw >> 4
     return valor

def converte_angulo():	#função para converter a leitura em ângulo arredondando com duas casas decimais
     global angulo
     angulo = round(valor * 360 / 4095,2)
     return angulo

def converte_passo():	#função para transformar a quantidade de passos em ângulo
     global passo
     passo = int((angulo / 0.1125)//1)
     return passo

def controla_motor():	#função para icrementar passos no sentido horário e anti-horário (sem lógica para o movimento mais próximo) 
    global posicao, direcao, motor
    motor = round(posicao * 0.1125,2)
    if(posicao - passo) >0:
        pin_dir.value(0)
        direcao = "anti-horário"
        pin_step.value(1)
        posicao -= 1
        utime.sleep(0.00005)
        pin_step.value(0)
    if (posicao - passo) <0:
        pin_dir.value(1)
        direcao = "horário"
        pin_step.value(1)
        posicao += 1
        utime.sleep(0.00005)
        pin_step.value(0)
        
    if passo == posicao:	#condição para minimizar passos de flutuação quando o pot estiver parado 
        utime.sleep(1)
        return posicao, motor
            
        

def le_tensao_motor():
    # global tensao_motor
    global valor_bruto
    valor_bruto = tensao_motor.read_u16() >> 4
    valor_bruto=valor_bruto/4095*3.3
    utime.sleep(1/10000)
    return valor_bruto

def controla_led(valor_bruto):
    if valor_bruto>0.01:
        led_pwm.duty_u16(65535)  # Define duty cycle máximo (3.3V)
    duty = int((valor_bruto / 3.3) * 65535)  # Converte tensão (0–3.3V) para duty cycle (0–65535)
    led_pwm.duty_u16(0)
while True:
    ler_potenciometro()
    converte_angulo()
    converte_passo()
    controla_motor()
    le_tensao_motor()
    controla_led(valor_bruto)
    print(f"Potenciometro: {valor}, Angulo Potenciometro: {angulo}, Angulo Motor: {motor}, Valor Passo: {passo}, Passo Motor: {posicao}, Direcao Motor: {direcao}")


    