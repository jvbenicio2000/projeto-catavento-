Mini - Wind Turbine by larsonmattr on Thingiverse: https://www.thingiverse.com/thing:4941

Summary:
This is a three blade wind turbine.  Just connect to a small motor and you can get up to around 1.4 volts in a good wind current.  It can double as a miniature fan, if you connect the motor up to a battery instead.  This is my first finished design for Thingiverse!
